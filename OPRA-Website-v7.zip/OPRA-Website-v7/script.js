"use strict";
/* Browser-only preview: no network requests, localStorage or real submissions. */
/* v7: left drawer (About, Blog, Industries; everything on mobile) */
const drawer=document.getElementById('site-drawer');
const drawerToggle=document.querySelector('.drawer-toggle');
const drawerPanel=drawer?.querySelector('.drawer-panel');
function openDrawer(){ if(!drawer)return; drawer.hidden=false; requestAnimationFrame(()=>drawer.classList.add('is-open')); drawerToggle.setAttribute('aria-expanded','true'); document.body.classList.add('drawer-open'); drawer.querySelector('.drawer-close').focus(); }
function closeDrawer(focusBack=true){ if(!drawer||drawer.hidden)return; drawer.classList.remove('is-open'); drawerToggle.setAttribute('aria-expanded','false'); document.body.classList.remove('drawer-open'); const done=()=>{drawer.hidden=true;}; window.matchMedia('(prefers-reduced-motion: reduce)').matches?done():setTimeout(done,260); if(focusBack)drawerToggle.focus(); }
drawerToggle?.addEventListener('click',()=>drawerToggle.getAttribute('aria-expanded')==='true'?closeDrawer():openDrawer());
drawer?.querySelectorAll('[data-close-drawer]').forEach(el=>el.addEventListener('click',()=>closeDrawer()));
drawer?.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>closeDrawer(false)));
drawer?.addEventListener('keydown',e=>{ if(e.key==='Escape'){closeDrawer();return;} if(e.key!=='Tab')return; const f=[...drawerPanel.querySelectorAll('a,button')].filter(el=>el.offsetParent!==null); const first=f[0],last=f[f.length-1]; if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();} else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();} });

/* v7: Industries dropdown */
const drop=document.querySelector('.nav-drop');
const dropBtn=drop?.querySelector('.drop-btn');
function setDrop(open){ if(!drop)return; drop.classList.toggle('open',open); dropBtn.setAttribute('aria-expanded',String(open)); }
dropBtn?.addEventListener('click',e=>{e.stopPropagation(); setDrop(!drop.classList.contains('open'));});
if(drop&&window.matchMedia('(hover: hover)').matches){ let t; drop.addEventListener('mouseenter',()=>{clearTimeout(t);setDrop(true);}); drop.addEventListener('mouseleave',()=>{t=setTimeout(()=>setDrop(false),150);}); }
document.addEventListener('click',e=>{ if(drop&&!drop.contains(e.target))setDrop(false); });
drop?.addEventListener('keydown',e=>{ if(e.key==='Escape'){setDrop(false);dropBtn.focus();} });
drop?.addEventListener('focusout',e=>{ if(!drop.contains(e.relatedTarget))setDrop(false); });

/* v7: blog topic filter */
document.querySelectorAll('.chips .chip').forEach(chip=>chip.addEventListener('click',()=>{
  const f=chip.dataset.filter;
  document.querySelectorAll('.chips .chip').forEach(c=>c.setAttribute('aria-pressed',String(c===chip)));
  document.querySelectorAll('.post-card').forEach(card=>{ card.hidden = f!=='All' && !card.dataset.cats.split('|').includes(f); });
}));

/* v7: employer form heading and button change with the service chosen */
const SERVICE_COPY={
  'Recruitment':['Send a <em>hiring brief.</em>','Tell us about the role. We will come back to discuss the brief, timing and next steps.','Send my brief'],
  'OPRA Flex':['Request <em>temporary staff.</em>','Share the role, location, shifts and start date. We will discuss cover that fits.','Request staff'],
  'Screening & re-vetting':['Request a <em>screening quote.</em>','Tell us the role and the checks you need. We will talk through what suits it before anything goes ahead.','Request my quote'],
  'HR support':['Book an <em>HR consultation.</em>','Tell us what is happening. We can discuss a one-off project, pay-as-you-go or ongoing support.','Book my consultation'],
  'Apprenticeships':['Plan an <em>apprenticeship.</em>','Tell us about the role and your team. We will help you explore where an apprenticeship fits.','Start planning'],
  'Wellbeing':['Book a <em>wellbeing assessment.</em>','Tell us about your team. We will discuss an assessment and what support could look like.','Book my assessment']
};
const empDialog=document.getElementById('employer-dialog');
const empDefault=empDialog?[empDialog.querySelector('#employer-title').innerHTML,empDialog.querySelector('.dialog-heading > p:not(.eyebrow)')?.textContent,empDialog.querySelector('.form-submit').textContent]:null;
function setEmployerCopy(service){ if(!empDialog)return; const c=SERVICE_COPY[service]||empDefault; empDialog.querySelector('#employer-title').innerHTML=c[0]; const p=empDialog.querySelector('.dialog-heading > p:not(.eyebrow)'); if(p)p.textContent=c[1]; empDialog.querySelector('.form-submit').textContent=c[2]; }
empDialog?.querySelector('select[name=service]')?.addEventListener('change',e=>setEmployerCopy(e.target.value));
document.querySelector('#year').textContent = new Date().getFullYear();
const dialogOpeners = new WeakMap();
function openDialog(id, opener) { const dialog=document.getElementById(id); if (!dialog) return; dialogOpeners.set(dialog,opener); dialog.showModal(); const role=opener?.dataset?.role; const msg=dialog.querySelector('textarea[name=message]'); if(role&&msg) msg.value='Applying for: '+role; const sector=dialog.querySelector('select[name=sector]'); if(sector&&opener?.dataset?.sector)sector.value=opener.dataset.sector; const service=dialog.querySelector('select[name=service]'); if(service)service.value=opener?.dataset?.service||'Recruitment'; if(id==='employer-dialog'){ setEmployerCopy(service?service.value:''); const ind=opener?.dataset?.industry; if(ind&&msg&&!msg.value)msg.value='Industry: '+ind; } if(msg&&opener?.dataset?.interest)msg.value='Interested in: '+opener.dataset.interest; closeDrawer(false); document.body.classList.add('modal-open'); }
document.querySelectorAll('[data-open]').forEach(opener=>opener.addEventListener('click',event=>{event.preventDefault();openDialog(opener.dataset.open,opener);}));
document.querySelectorAll('dialog').forEach(dialog=>{
 dialog.querySelector('.dialog-close').addEventListener('click',()=>dialog.close());
 dialog.addEventListener('click',event=>{ if(event.target!==dialog)return; const rect=dialog.getBoundingClientRect();if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)dialog.close(); });
 dialog.addEventListener('close',()=>{if(!document.querySelector('dialog[open]'))document.body.classList.remove('modal-open');const form=dialog.querySelector('form');if(form){form.reset();form.querySelector('.form-feedback').hidden=true;if(form.id==='cv-form')clearFile();}const opener=dialogOpeners.get(dialog);if(opener?.isConnected)opener.focus();});
});
const fileInput=document.getElementById('cv-file');
const fileStatus=document.getElementById('file-status');
const removeFile=document.getElementById('remove-file');
const dropZone=document.getElementById('file-drop');
function clearFile(){fileInput.value='';fileInput.setCustomValidity('');fileStatus.textContent='';removeFile.hidden=true;}
function validateFile(){const file=fileInput.files[0];if(!file){clearFile();return false;}let error='';if(!/\.(pdf|doc|docx)$/i.test(file.name))error='Choose a PDF, DOC or DOCX file.';else if(file.size===0)error='This file is empty. Choose a different CV.';else if(file.size>10*1024*1024)error='This file is too large. Choose a CV under 10 MB.';fileInput.setCustomValidity(error);fileStatus.textContent=error||`${file.name} · ${(file.size/1024/1024).toFixed(2)} MB · selected for preview`;removeFile.hidden=false;return !error;}
fileInput.addEventListener('change',validateFile);removeFile.addEventListener('click',clearFile);
['dragenter','dragover'].forEach(type=>dropZone.addEventListener(type,event=>{event.preventDefault();dropZone.classList.add('drag-over');}));
['dragleave','drop'].forEach(type=>dropZone.addEventListener(type,event=>{event.preventDefault();dropZone.classList.remove('drag-over');}));
dropZone.addEventListener('drop',event=>{const files=event.dataTransfer.files;if(files.length!==1){fileStatus.textContent='Please choose one CV file.';return;}fileInput.files=files;validateFile();});
['cv-form','employer-form'].forEach(id=>document.getElementById(id).addEventListener('submit',event=>{event.preventDefault();const form=event.currentTarget;if(id==='cv-form'&&!validateFile()){fileInput.reportValidity();return;}if(!form.reportValidity())return;const feedback=form.querySelector('.form-feedback');feedback.replaceChildren();const heading=document.createElement('strong');heading.textContent=id==='cv-form'?'CV form checked (preview).':'Enquiry checked (preview).';const text=document.createElement('p');text.textContent=id==='cv-form'?'Your form and file selection have been checked. This is a design preview: your CV has not been uploaded or sent.':'Your enquiry has been checked. This is a design preview: your enquiry has not been sent.';feedback.append(heading,text);feedback.hidden=false;feedback.scrollIntoView({block:'nearest',behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});}));

function revealLinkedSection(){
  const id=decodeURIComponent(location.hash.slice(1));
  const target=document.getElementById(id);
  if(target?.tagName==='DETAILS')target.open=true;
}
window.addEventListener('hashchange',revealLinkedSection);
document.querySelectorAll('.site-footer a[href^="#"]').forEach(link=>link.addEventListener('click',()=>{
 const target=document.getElementById(link.hash.slice(1));
 if(target?.tagName==='DETAILS')target.open=true;
}));
revealLinkedSection();
