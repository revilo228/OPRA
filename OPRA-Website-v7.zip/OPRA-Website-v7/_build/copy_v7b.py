"""Cashvertising copy pass (v7b). Run from site root BEFORE build.py so new pages inherit dialog/footer copy."""
import os, re, sys
sys.path.insert(0, os.path.dirname(__file__))
from content import about_values_team
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

ALL = [  # every page: dialogs, footer
 ('Our recruiters can help you explore relevant opportunities.', 'A sector specialist will match you with roles that fit.'),
 ('>Discuss your hiring needs<', '>Send a hiring brief<'),
 ('Share the role or people challenge you need help with. We can discuss the scope, timing and next steps.', 'Tell us the role or the problem. We will come back with the next steps.'),
 ('<p>hire retention reported by OPRA</p>', '<p>hire retention</p>'),
 ('<p>of clients acquired through recommendation, as reported by OPRA</p>', '<p>of new clients come through a recommendation</p>'),
 ('<p>years of experience, as published by OPRA</p>', '<p>years of experience</p>'),
 ('<ul><li>REC Member</li>', '<ul><li>Business Elite Awards 2026 winner</li><li>REC Member</li>'),
 ('Client quote is an excerpt.</p>', 'Client quote is an excerpt. Award: <a href="https://theopragroup.com/2026/06/08/the-opra-group-wins-best-integrated-recruitment-hr-solutions-provider-2026/" target="_blank" rel="noopener">Business Elite Awards 2026</a>.</p>'),
]

PAGE = {
"index.html": [
 ('<p class="eyebrow"><span class="dot"></span>Less stress. More progress.</p>', '<p class="eyebrow"><span class="dot"></span>Recruitment, screening and HR. One team.</p>'),
 ('<h1>Recruitment for dental &amp; healthcare, financial services and logistics.</h1>', '<h1>Dental, finance and logistics hires <em>that stay.</em></h1>'),
 ('<p class="hero-description">Permanent, temporary and contract recruitment across the UK. We take time to understand the role, the person and the move that comes next.</p>',
  '<p class="hero-description">98% hire retention. Permanent, temporary and contract recruitment across the UK, with screening and HR from the same team. One brief, no juggling suppliers.</p>'),
 ('<span class="route-sub">Start with your experience</span>', '<span class="route-sub">Get matched by a sector specialist</span>'),
 ('<strong>Find staff</strong>\n          <span class="route-sub">Send us a short brief</span>', '<strong>Send a hiring brief</strong>\n          <span class="route-sub">A short form, then a call</span>'),
 ('Planning your next move? <a href="jobs.html">Explore jobs &amp; careers</a>', 'Looking for work? <a href="jobs.html">See current jobs</a>'),
 ('<span>Growing talent together</span>\n        <strong>Offices in London, Essex &amp; Glasgow</strong>', '<span>Award winner 2026</span>\n        <strong>Best Integrated Recruitment &amp; HR Solutions Provider</strong>'),
 ('<h2 id="sectors-title">People who understand <em>your world.</em></h2>', '<h2 id="sectors-title">Specialists in <em>three industries.</em></h2>'),
 ('<p class="section-intro">Our core focus is dental, health &amp; social care, financial services, and facilities &amp; logistics. Tell us what you need from your next role or your next hire.</p>',
  '<p class="section-intro">Pick yours. Each has its own team who knows the roles, the pay and the people.</p>'),
 ('<p>For practices, healthcare teams and people building a career in care. Start with the experience, qualifications and working pattern the role needs.</p>',
  '<p>An empty nurse slot means cancelled patients. We fill practice teams, clinical roles and management positions, permanent or temporary.</p>'),
 ('<p>Recruitment across financial services and insurance. A useful match starts with understanding the role’s responsibilities, relevant experience and team.</p>',
  '<p>In a regulated role, the wrong hire is costly to undo. We recruit across financial services and insurance, from specialists to senior leaders.</p>'),
 ('<p>People to support sites and day-to-day operations. Location, shifts and availability matter as much as experience when discussing the right fit.</p>',
  '<p>A short shift is a missed delivery. We staff sites with permanent hires or on-demand cover through OPRA Flex.</p>'),
 ('<a class="button button-lime" href="#employer-dialog" data-open="employer-dialog">Find staff</a>\n      </div>\n    </div>\n    <p class="section-tail">',
  '<a class="button button-lime" href="#employer-dialog" data-open="employer-dialog">Send a hiring brief</a>\n      </div>\n    </div>\n    <p class="section-tail">'),
 (' Registration does not guarantee a vacancy or placement.', ''),
 ('We can discuss the rest with you.', 'We will fill in the rest on a call.'),
 ('Yes. OPRA offers HR support alongside recruitment, screening, apprenticeships and wellbeing services. We can discuss a specific project or ongoing support.</p><a class="inline-link" href="services.html#people-support">Explore employer services →</a>',
  'Yes. Our CIPD-qualified HR consultants work alongside your team, on a one-off project or ongoing.</p><a class="inline-link" href="services.html#hr">See HR support →</a>'),
 ('<h2>Ready when <em>you are.</em></h2>\n      <p class="final-sub">Prefer to talk first? Call',
  '<h2>Every week a seat stays empty <em>costs you.</em></h2>\n      <p class="final-sub">Send a brief today, or call'),
 ('<a class="button button-lime" href="#cv-dialog" data-open="cv-dialog">Upload your CV</a>\n      <a class="button button-outline-light" href="#employer-dialog" data-open="employer-dialog">Find staff</a>',
  '<a class="button button-lime" href="#employer-dialog" data-open="employer-dialog">Send a hiring brief</a>\n      <a class="button button-outline-light" href="#cv-dialog" data-open="cv-dialog">Upload your CV</a>'),
],
"about.html": [
 ('<h1>At OPRA, we specialise <em>in people.</em></h1>', '<h1>The recruiter that stays <em>after the hire.</em></h1>'),
 ('with a core focus on dental, health &amp; social care, financial services, and facilities &amp; logistics.</p>', 'with a core focus on three industries: dentistry and healthcare, finance, and logistics.</p>'),
 ('<p>For candidates, that means help with CVs, interviews and the move into work. For employers, it means a search built around the role, with screening, HR, apprenticeship and wellbeing support available when needed.</p>',
  '<p>If you are looking for work, you get help with your CV, interviews and the move into your new role. If you are hiring, you get a search built around the role, plus screening, HR, apprenticeship and wellbeing support when you need it.</p>'),
 ('Less stress, more progress. Let\'s embark on a journey of employment success, together.', 'Less stress, more progress.'),
 ('Our recruiters also discuss work history', 'Our recruiters also dig into work history'),
 ('Our services can be discussed separately, so the starting point stays focused on what you need.', 'Use one service or several. Start with whatever is most urgent.'),
 ('See how we can support your business →', 'See employer services →'),
 ('<ul class="values"><li>98% hire retention reported by OPRA</li><li>70% of clients acquired by recommendation</li><li>40+ years\' experience, as published by OPRA</li></ul>',
  '<ul class="values"><li>98% hire retention</li><li>70% of new clients come through a recommendation</li><li>40+ years of experience</li><li>Business Elite Awards 2026 winner</li></ul>'),
],
"jobs.html": [
 ('Explore OPRA’s jobs board or share your experience with our recruiters.', 'Search the live jobs board, or send your CV and let a sector specialist find roles for you.'),
 ('>Discuss care opportunities<', '>Find a care role<'),
 ('We can explore opportunities relevant to your background.', 'We will match you with roles that fit your background.'),
 ('>Discuss finance opportunities<', '>Find a finance role<'),
 ('>Discuss operational roles<', '>Find shift work<'),
 ('Register your CV so OPRA can consider your experience for relevant opportunities.', 'Send your CV and we will keep you in mind for new roles as they come in.'),
 ('>Discuss flexible work<', '>Find temporary work<'),
 ('Explore OPRA’s apprenticeship support ↗', 'See apprenticeship support ↗'),
 ('<p>Explore permanent recruitment, temporary staffing and support beyond the hire. Start with the role or challenge you need help with.</p>',
  '<p>Permanent hires, temporary cover, screening and HR from one team. Send a brief and we will take it from there.</p>'),
 ('<a class="button button-lime" href="services.html">Explore employer services</a>', '<a class="button button-lime" href="services.html">See employer services</a>'),
 ('content="Explore OPRA’s current jobs board', 'content="Search OPRA’s current jobs board'),
],
"services.html": [
 ('Start with what your business needs and we’ll help you explore the right support.', 'Tell us the problem. We will match the fix: a hire, temporary cover, screening or HR.'),
 ('data-open="employer-dialog">Discuss your needs</a><a class="inline-link" href="#people-support">Explore people services ↓</a>',
  'data-open="employer-dialog">Send a brief</a><a class="inline-link" href="#people-support">See people services ↓</a>'),
 ('Our core sectors are dental, health &amp; social care, financial services, and facilities &amp; logistics. We also work across other industries; talk to us about your requirement.</p>',
  'We also recruit outside our three core industries. Tell us the role.</p>'),
 ('We discuss the role and assess', 'We dig into the role, then assess'),
 ('We discuss the skills, location and working pattern you need.', 'Tell us the skills, location and working pattern. We will find the people.'),
 ('Use a specific service or discuss a wider requirement. The scope is shaped around your business.', 'Use one service, or bring us the whole problem.'),
 ('Talk through which checks are appropriate and what the service covers before proceeding.', 'We confirm which checks fit the role before anything goes ahead.'),
 ('<p>Discuss a one-off project, pay-as-you-go support or an ongoing retained service.</p>', '<p>Choose a one-off project, pay-as-you-go support or an ongoing retained service.</p>'),
 ('We can help you explore where apprenticeships fit your workforce plans.', 'We will show you where apprenticeships fit your workforce plans.'),
 ('We can discuss where external help would be useful.', 'We will tell you where outside help is worth it, and where it is not.'),
 ('That depends on the service and scope. Tell us what you need so we can discuss the work involved and the relevant fees and terms.',
  'Fees depend on the service and scope. Send a brief and we will set out clear fees and terms before any work starts.'),
 ('<h2>Start with <em>the challenge.</em></h2>', '<h2>Start with <em>the problem.</em></h2>'),
 ('data-open="employer-dialog">Discuss your needs</a><a class="button button-outline-light" href="jobs.html">Looking for work?</a>',
  'data-open="employer-dialog">Send a brief</a><a class="button button-outline-light" href="jobs.html">Looking for work?</a>'),
 ('Discuss your hiring or people needs with OPRA Group.', 'Send a brief to OPRA Group.'),
],
}

for page, reps in PAGE.items():
    p = os.path.join(ROOT, page); s = open(p, encoding="utf-8").read()
    for a, b in reps + ALL:
        if a not in s and b in s: continue  # already applied
        if a not in s:
            if (a, b) in ALL: continue      # global item not present on this page
            raise SystemExit(f"{page}: not found: {a[:70]}")
        s = s.replace(a, b)
    if page == "about.html":  # re-render values + team from content.py
        s = re.sub(r'\n<section class="section values-section".*?</section>\s*<section class="section team-section".*?</section>\n', about_values_team(), s, count=1, flags=re.S)
    open(p, "w", encoding="utf-8").write(s)
print("copy pass done")
