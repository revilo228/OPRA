"""Shared header, drawer and footer pieces for OPRA v7. Imported by build.py."""

PHONE = '0204 548 5066'
TEL = 'tel:+442045485066'

INDUSTRIES = [
    ("industry-dentistry.html", "Dentistry", "Dental nurses, clinicians, practice teams and managers."),
    ("industry-finance.html", "Finance", "Financial services and insurance roles, from specialists to leaders."),
    ("industry-logistics.html", "Logistics", "Facilities, site and operational teams, permanent and flexible."),
]

CHEVRON = '<svg class="chev" viewBox="0 0 12 8" aria-hidden="true"><path d="M1 1.5 6 6.5l5-5" fill="none" stroke="currentColor" stroke-width="1.8"/></svg>'


def header(active=""):
    def cur(page):
        return ' aria-current="page"' if page == active else ""
    drop = "".join(
        f'<a href="{h}" role="menuitem"{cur(h)}><strong>{n}</strong><span>{d}</span></a>' for h, n, d in INDUSTRIES)
    ind_active = ' is-active' if active.startswith("industry-") else ""
    return f'''<header class="site-header">
  <div class="wrap nav-inner v7-nav">
    <button class="drawer-toggle" type="button" aria-expanded="false" aria-controls="site-drawer">
      <span class="sr-only">Open menu</span><span class="drawer-bars" aria-hidden="true"></span>
    </button>
    <a class="wordmark" href="index.html" aria-label="OPRA Group, home">
      <img class="brand-logo" src="assets/opra-brand-logo-light.svg" width="360" height="100" alt="OPRA, Growing Talent Together">
    </a>
    <nav class="top-nav" aria-label="Main navigation">
      <div class="nav-drop{ind_active}">
        <button class="drop-btn" type="button" aria-expanded="false" aria-controls="industries-menu">Industries {CHEVRON}</button>
        <div class="drop-panel" id="industries-menu" role="menu">{drop}</div>
      </div>
      <a href="jobs.html"{cur("jobs.html")}>Jobs &amp; Careers</a>
      <a href="services.html"{cur("services.html")}>For Employers</a>
      <a href="{TEL}" class="nav-phone">{PHONE}</a>
      <a class="button button-small button-lime" href="#cv-dialog" data-open="cv-dialog">Upload your CV</a>
    </nav>
    <a class="button button-small button-lime mobile-cta" href="#cv-dialog" data-open="cv-dialog">Upload CV</a>
  </div>
  <svg class="header-wing" viewBox="0 0 1440 24" preserveAspectRatio="none" aria-hidden="true"><path d="M0 0h1440v6C1080 26 700 26 360 12 220 6 100 4 0 8z"/></svg>
</header>

<div class="drawer" id="site-drawer" hidden>
  <div class="drawer-scrim" data-close-drawer></div>
  <aside class="drawer-panel" role="dialog" aria-modal="true" aria-label="Menu">
    <div class="drawer-top">
      <img class="brand-logo" src="assets/opra-brand-logo.svg" width="360" height="100" alt="OPRA">
      <button class="drawer-close" type="button" data-close-drawer aria-label="Close menu">×</button>
    </div>
    <nav aria-label="Menu">
      <p class="drawer-label">Company</p>
      <a class="drawer-link" href="about.html"{cur("about.html")}>About Us</a>
      <a class="drawer-link" href="blog.html"{cur("blog.html")}>Blog</a>
      <p class="drawer-label">Industries</p>
      {"".join(f'<a class="drawer-link" href="{h}"{cur(h)}>{n}</a>' for h, n, d in INDUSTRIES)}
      <div class="drawer-mobile-only">
        <p class="drawer-label">Explore</p>
        <a class="drawer-link" href="jobs.html"{cur("jobs.html")}>Jobs &amp; Careers</a>
        <a class="drawer-link" href="services.html"{cur("services.html")}>For Employers</a>
      </div>
    </nav>
    <div class="drawer-foot">
      <a class="drawer-phone" href="{TEL}">Call {PHONE}</a>
      <a class="button button-lime" href="#cv-dialog" data-open="cv-dialog">Upload your CV</a>
      <a class="button button-dark" href="#employer-dialog" data-open="employer-dialog">Find staff</a>
    </div>
  </aside>
</div>'''


FOOTER_EXPLORE = ('<ul><li><a href="about.html">About OPRA</a></li><li><a href="blog.html">Blog</a></li>'
                  '<li><a href="industry-dentistry.html">Dentistry</a></li><li><a href="industry-finance.html">Finance</a></li>'
                  '<li><a href="industry-logistics.html">Logistics</a></li><li><a href="jobs.html">Jobs &amp; Careers</a></li>'
                  '<li><a href="https://jobs.theopragroup.com/" target="_blank" rel="noopener">Current jobs ↗</a></li>'
                  '<li><a href="https://jobs.theopragroup.com/login.aspx" target="_blank" rel="noopener">Candidate login ↗</a></li></ul>')

PLACEHOLDER_AVATAR = ('<svg class="avatar-ph" viewBox="0 0 120 120" aria-hidden="true"><rect width="120" height="120" rx="14"/>'
                      '<circle cx="60" cy="46" r="20"/><path d="M22 112c4-24 20-36 38-36s34 12 38 36z"/></svg>')


def person(role, area):
    return (f'<article class="person-card">{PLACEHOLDER_AVATAR}<div><span class="ph-tag">Photo to come</span>'
            f'<h3>[Team member name]</h3><p class="person-role">{role}</p><p class="person-area">{area}</p></div></article>')
