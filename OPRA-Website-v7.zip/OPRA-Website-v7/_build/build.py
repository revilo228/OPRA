"""Patch the v6 pages into v7. Run once: python3 _build/build.py (from the site root)."""
import re, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from partials import header, FOOTER_EXPLORE
from content import INDUSTRY, industry_main, blog_main, about_values_team

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def rd(n): return open(os.path.join(ROOT, n), encoding="utf-8").read()
def wr(n, s): open(os.path.join(ROOT, n), "w", encoding="utf-8").write(s)

HEADER_RE = re.compile(r'<header class="site-header">.*?</header>(\s*<div class="drawer".*?</aside>\s*</div>)?', re.S)
EXPLORE_RE = re.compile(r'(<h2 id="footer-explore">Explore</h2>\s*)<ul>.*?</ul>', re.S)


def common(html, page):
    html = HEADER_RE.sub(lambda m: header(page), html, count=1)
    html = EXPLORE_RE.sub(lambda m: m.group(1) + FOOTER_EXPLORE, html, count=1)
    html = re.sub(r'styles\.css\?v=\d+', 'styles.css?v=7', html)
    html = re.sub(r'script\.js(\?v=\d+)?"', 'script.js?v=7"', html)
    return html


# ---- existing pages ----
for page in ["index.html", "about.html", "jobs.html", "services.html"]:
    html = common(rd(page), page)

    if page == "about.html" and 'class="value-grid"' not in html:
        html = re.sub(r'\s*<h2>Our core <em>values\.</em></h2>\s*<ul class="core-values">.*?</ul>', '', html, flags=re.S)
        html = html.replace('<section class="section reviews" id="proof">', about_values_team() + '\n<section class="section reviews" id="proof">', 1)

    if page == "services.html":
        swaps = [
            ('data-service="Recruitment">Discuss a vacancy<', 'data-service="Recruitment">Send a hiring brief<'),
            ('data-service="OPRA Flex">Discuss staffing needs<', 'data-service="OPRA Flex">Request temporary staff<'),
            ('Discuss screening →', 'Request a screening quote →'),
            ('Discuss HR support →', 'Book an HR consultation →'),
            ('Discuss apprenticeships →', 'Plan an apprenticeship →'),
            ('Discuss wellbeing →', 'Book a wellbeing assessment →'),
        ]
        for a, b in swaps:
            html = html.replace(a, b)
        # Industry quick links under the recruitment intro
        if 'class="ind-links"' not in html:
            html = html.replace('talk to us about your requirement.</p></div>',
                'talk to us about your requirement.</p><p class="ind-links">See our work in <a href="industry-dentistry.html">Dentistry</a>, <a href="industry-finance.html">Finance</a> and <a href="industry-logistics.html">Logistics</a>.</p></div>', 1)

    if page == "index.html":
        html = html.replace('<a class="inline-link" href="jobs.html#sectors">Explore your next move <span aria-hidden="true">→</span></a>',
                            '<a class="inline-link" href="industry-dentistry.html">Dentistry: hire or find a role <span aria-hidden="true">→</span></a>')
        html = html.replace('<a class="inline-link" href="services.html#recruitment">Discuss your next hire <span aria-hidden="true">→</span></a>',
                            '<a class="inline-link" href="industry-finance.html">Finance: hire or find a role <span aria-hidden="true">→</span></a>')
        html = html.replace('<a class="inline-link" href="services.html#flex">Explore staffing support <span aria-hidden="true">→</span></a>',
                            '<a class="inline-link" href="industry-logistics.html">Logistics: hire or find work <span aria-hidden="true">→</span></a>')
        html = html.replace('<a href="services.html#people-support">Explore screening, HR, apprenticeships and wellbeing →</a>',
                            '<a href="services.html#screening">Request a screening quote →</a> or <a href="services.html#hr">book an HR consultation →</a>')
    wr(page, html)


# ---- new pages, built on the services.html shell ----
shell = rd("services.html")
main_re = re.compile(r'<main id="main">.*?</main>', re.S)


def make(page, title, desc, main):
    html = header_page = shell
    html = re.sub(r'<title>.*?</title>', '<title>' + title + '</title>', html, count=1)
    html = re.sub(r'<meta name="description" content=".*?">', '<meta name="description" content="' + desc + '">', html, count=1)
    html = HEADER_RE.sub(lambda m: header(page), html, count=1)
    html = main_re.sub(lambda m: main, html, count=1)
    wr(page, html)


for page, d in INDUSTRY.items():
    make(page, d["title"], d["desc"], industry_main(page))
make("blog.html", "Blog | OPRA Group", "Practical advice on hiring, HR, employment law and careers from The OPRA Group.", blog_main())
print("built")
