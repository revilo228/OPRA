"""Page content for OPRA v7: industry pages, blog and the improved About sections."""
from partials import person, TEL, PHONE

# ---------------- Industries ----------------
INDUSTRY = {
  "industry-dentistry.html": dict(
    title="Dental Recruitment | OPRA Group",
    desc="Dental recruitment for practices and groups across the UK: practice teams, clinicians and managers, permanent, temporary and contract.",
    name="Dentistry", key="Dentistry", cv_sector="Dental, health &amp; social care",
    h1="Fill the gaps <em>on your rota.</em>",
    lead="A gap on the rota means cancelled patients and a stretched team. We recruit dental nurses, clinicians and practice managers on a permanent, temporary or contract basis, and run the checks before day one.",
    hire="Hire dental staff", find="Find a dental role",
    exp_intro="Our dental team works with practices of every size, and with candidates at every stage of their dental career. Dentistry sits within our wider health &amp; social care focus.",
    cards=[("Practice teams", "Dental nurses, receptionists and treatment coordinators who keep the day running."),
           ("Clinical roles", "Dentists, hygienists and therapists, matched on experience, availability and the way your practice works."),
           ("Practice leadership", "Practice managers and multi-site roles for growing groups.")],
    logos=[("client-together-dental.png", "Together Dental", 289, 98)],
    results=["Number of dental roles filled for a group", "Time to fill a clinical vacancy", "A practice testimonial with name and role"],
    team=[("Dental Recruitment Consultant", "Practice teams"), ("Senior Consultant", "Clinical roles"), ("OPRA Flex Coordinator", "Temporary dental cover")],
    screen=("Checks for clinical teams", "Need DBS, right-to-work or qualification checks for new clinical starters? We can talk through the checks that suit the role.", "Request a screening quote"),
  ),
  "industry-finance.html": dict(
    title="Financial Services Recruitment | OPRA Group",
    desc="Financial services and insurance recruitment across the UK: permanent, contract and executive search.",
    name="Finance", key="Finance", cv_sector="Financial services",
    h1="Finance hires that fit the role <em>and the team.</em>",
    lead="In a regulated role, the wrong hire is slow and costly to undo. We recruit across financial services and insurance, from specialists to senior leaders, with screening built in.",
    hire="Hire finance talent", find="Find a finance role",
    exp_intro="Our finance team recruits across financial services and insurance, from specialist hires to senior appointments.",
    cards=[("Operations &amp; client services", "People who keep processes, clients and service levels on track."),
           ("Risk, compliance &amp; finance", "Specialists for regulated, detail-led roles."),
           ("Senior &amp; executive search", "Leadership appointments handled with discretion.")],
    logos=[("client-fnz.png", "FNZ", 206, 86), ("client-ssc.png", "SS&amp;C", 238, 136)],
    results=["Number of finance roles filled", "An executive search outcome", "A client testimonial with name and role"],
    team=[("Financial Services Consultant", "Permanent hires"), ("Executive Search Lead", "Senior appointments"), ("Contract Recruitment Consultant", "Interim and contract roles")],
    screen=("Checks for regulated roles", "Credit, sanctions and employment-history checks can be shaped around the role and your requirements.", "Request a screening quote"),
  ),
  "industry-logistics.html": dict(
    title="Logistics &amp; Facilities Recruitment | OPRA Group",
    desc="Facilities and logistics recruitment across the UK: site and operational teams, permanent and flexible staffing with OPRA Flex.",
    name="Logistics", key="Logistics", cv_sector="Facilities &amp; logistics",
    h1="Logistics staffing that <em>keeps sites moving.</em>",
    lead="An empty shift means missed loads and an overworked team. We supply permanent staff and flexible cover through OPRA Flex, matched on location, shifts and experience.",
    hire="Request staff", find="Find logistics work",
    exp_intro="Our logistics team supports sites with permanent hires and flexible cover through OPRA Flex, for short-term, longer or volume requirements.",
    cards=[("Warehouse &amp; distribution", "Operatives and team leaders for busy sites and changing demand."),
           ("Facilities &amp; site services", "People who keep buildings and sites running day to day."),
           ("Supervisors &amp; managers", "Operational leaders for shifts, sites and teams.")],
    logos=[],
    results=["Workers placed for a peak period", "Fill rate for a volume requirement", "A site manager testimonial with name and role"],
    team=[("Logistics Recruitment Consultant", "Permanent hires"), ("OPRA Flex Coordinator", "Temporary and volume cover"), ("Account Manager", "Ongoing site requirements")],
    screen=("Flexible cover, ready when you are", "OPRA Flex supports short-term cover, longer assignments and temporary-to-permanent arrangements.", "Request temporary staff"),
  ),
}


def industry_main(page):
    d = INDUSTRY[page]
    key = d["key"]
    cards = "".join(f'<article class="info-card"><span class="card-number" aria-hidden="true">0{i+1}</span><h3>{t}</h3><p>{p}</p></article>' for i, (t, p) in enumerate(d["cards"]))
    logos = "".join(f'<li class="ind-logo"><img src="assets/{f}" width="{w}" height="{h}" alt="{a}" loading="lazy"></li>' for f, a, w, h in d["logos"])
    logo_block = (f'<div class="ind-logos"><p class="logos-label">{d["name"]} companies OPRA has worked with</p><ul>{logos}</ul></div>' if logos else "")
    results = "".join(f'<article class="result-card placeholder-card"><span class="ph-tag">Result to add</span><strong>[Number or outcome]</strong><p>{r}</p></article>' for r in d["results"])
    team = "".join(person(r, a) for r, a in d["team"])
    s_title, s_copy, s_cta = d["screen"]
    s_service = "OPRA Flex" if "temporary" in s_cta.lower() else "Screening &amp; re-vetting"
    return f'''<main id="main">

<section class="page-hero industry-hero">
  <div class="wrap">
    <p class="eyebrow eyebrow-light"><span class="dot"></span>Industries · {d["name"]}</p>
    <h1>{d["h1"]}</h1>
    <p class="page-lead">{d["lead"]}</p>
    <div class="route-cards ind-routes">
      <a class="route-card route-primary" href="#employer-dialog" data-open="employer-dialog" data-service="Recruitment" data-industry="{key}">
        <span class="route-label">I'm hiring</span><strong>{d["hire"]}</strong><span class="route-sub">Send a short brief</span><span class="route-arrow" aria-hidden="true">→</span></a>
      <a class="route-card route-secondary" href="#cv-dialog" data-open="cv-dialog" data-sector="{d["cv_sector"]}">
        <span class="route-label">I'm looking for work</span><strong>{d["find"]}</strong><span class="route-sub">Start with your CV</span><span class="route-arrow" aria-hidden="true">→</span></a>
    </div>
  </div>
</section>

<section class="section" id="experience">
  <div class="wrap">
    <div class="section-heading"><p class="eyebrow">Our experience</p><h2>Where we help in <em>{d["name"].lower()}.</em></h2><p class="section-intro">{d["exp_intro"]}</p></div>
    <div class="info-grid">{cards}</div>
  </div>
</section>

<section class="section ind-results" id="results">
  <div class="wrap">
    <div class="section-heading"><p class="eyebrow">Results</p><h2>What we've delivered <em>for {d["name"].lower()} clients.</em></h2></div>
    {logo_block}
    <div class="result-grid">{results}</div>
    <p class="review-source">Placeholders: OPRA to supply real, approved results and testimonials for this industry.</p>
  </div>
</section>

<section class="section" id="team">
  <div class="wrap">
    <div class="section-heading"><p class="eyebrow">Your specialists</p><h2>Meet our <em>{d["name"]} team.</em></h2><p class="section-intro">The people who handle {d["name"].lower()} roles day to day.</p></div>
    <div class="team-grid team-grid-3">{team}</div>
  </div>
</section>

<section class="section ind-extra">
  <div class="wrap ind-extra-inner">
    <div><p class="eyebrow">Beyond the hire</p><h2>{s_title}</h2><p class="section-intro">{s_copy}</p></div>
    <a class="button button-dark" href="#employer-dialog" data-open="employer-dialog" data-service="{s_service}" data-industry="{key}">{s_cta}</a>
  </div>
</section>

<section class="final-cta">
  <div class="wrap final-inner">
    <div><p class="eyebrow eyebrow-light">{d["name"]}</p><h2>Ready when <em>you are.</em></h2><p class="final-sub">Prefer to talk? Call <a href="{TEL}">{PHONE}</a></p></div>
    <div class="final-actions">
      <a class="button button-lime" href="#employer-dialog" data-open="employer-dialog" data-service="Recruitment" data-industry="{key}">{d["hire"]}</a>
      <a class="button button-outline-light" href="#cv-dialog" data-open="cv-dialog" data-sector="{d["cv_sector"]}">{d["find"]}</a>
    </div>
  </div>
</section>

</main>'''


# ---------------- Blog ----------------
IMG = "https://theopragroup.com/wp-content/uploads/"
POSTS = [
  ("2026-07-28", "The Cost of Avoiding HR Advice", "2026/07/28/the-cost-of-avoiding-hr-advice/", "2026/07/1-The-Cost-of-The-Cost-of-Avoiding-HR-Advice-Blog-1200-X-900.jpg", ["HR", "Leadership"],
   "Waiting for problems to arise is often the most expensive approach. Why HR advice pays off before something goes wrong."),
  ("2026-07-20", "The Cost of Reactive Leadership", "2026/07/20/the-cost-of-reactive-leadership/", "2026/07/1-The-Cost-of-Reactive-Leadership-Blog-1200-X-900.jpg", ["Employer tips", "Leadership"],
   "The most effective leaders aren't just good at reacting. They're skilled at preventing problems before they start."),
  ("2026-07-17", "The Cost of Inconsistency in the Workplace", "2026/07/17/the-cost-of-inconsistency-in-the-workplace/", "2026/07/1-Inconsistency-in-the-Workplace-Blog-1200-X-900.jpg", ["HR", "Leadership"],
   "Consistency rarely gets talked about, but its absence quietly damages teams, trust and results."),
  ("2026-06-29", "Building Connections, Sharing Knowledge", "2026/06/29/building-connections-sharing-knowledge/", "2026/06/1-Workforce-2026-Why-Networking-and-Employment-Law-Go-Hand-in-Hand-Blog-1200-X-900-1.jpg", ["Employer tips", "HR"],
   "Why The OPRA Group is investing in more in-person events, and why staying informed matters as much as staying connected."),
  ("2026-06-26", "Is Your Business Ready for the Biggest Employment Law Changes in a Generation?", "2026/06/26/is-your-business-ready-for-the-biggest-employment-law-changes-in-a-generation/", "2026/06/1-Employment-Rights-Act-2025-Is-Your-Business-Ready-for-the-Biggest-Employment-Law-Changes-in-a-Generation-Blog-1200-X-900.jpg", ["Employer tips", "HR"],
   "The Employment Rights Act 2025 is one of the biggest reforms to UK employment law in decades. What businesses recruiting now should know."),
  ("2026-06-08", "The OPRA Group Wins Best Integrated Recruitment & HR Solutions Provider 2026", "2026/06/08/the-opra-group-wins-best-integrated-recruitment-hr-solutions-provider-2026/", "2026/06/1-The-OPRA-Group-Wins-Best-Integrated-Recruitment-HR-Solutions-Provider-2026-Blog-1200-X-900.jpg", ["News"],
   "OPRA has been named Best Integrated Recruitment &amp; HR Solutions Provider 2026 at the Business Elite Awards."),
  ("2026-03-31", "Spring Into Your New Job: Event Round-Up", "2026/03/31/spring-into-your-new-job-event-round-up/", "2026/03/1-Candidate-Evemt-March-2026-Blog-1200-X-900.jpg", ["Candidates"],
   "Highlights from our Spring Into Your New Job event, bringing together industry experts and job seekers."),
  ("2026-03-30", "The Cost of Unclear Values", "2026/03/30/the-cost-of-unclear-values/", "2026/03/1-Poor-Unclear-Values-Blog-1200-X-900.jpg", ["Employer tips", "Leadership"],
   "Business values are the foundation of company culture. What happens when they're unclear, and how to fix it."),
  ("2026-02-24", "The Cost of Poor Communication During Change", "2026/02/24/the-cost-of-poor-communication-during-change/", "2026/02/1-Poor-Communication-During-Change-Blog-1200-X-900.jpg", ["HR", "Leadership"],
   "Why outplacement matters more than you think, and why poor communication during change is such an expensive mistake."),
  ("2026-02-13", "The Cost of Unmanaged Stress: Why Doing Nothing Is No Longer an Option", "2026/02/13/the-cost-of-unmanaged-stress-why-doing-nothing-is-no-longer-an-optiion/", "2026/02/1-Unmanaged-Stress-Blog-1200-X-900.jpg", ["Employer tips", "Wellbeing"],
   "Workplace stress isn't new, but the scale of its impact is becoming impossible to ignore."),
]


def fmt(d):
    import datetime
    return datetime.date.fromisoformat(d).strftime("%-d %B %Y")


def blog_main():
    cats = ["All"] + sorted({c for p in POSTS for c in p[4]})
    chips = "".join(f'<button class="chip" type="button" data-filter="{c}" aria-pressed="{str(c == "All").lower()}">{c}</button>' for c in cats)

    def card(p, featured=False):
        date, title, slug, img, c, ex = p
        tags = "".join(f'<span class="tag">{t}</span>' for t in c)
        cls = "post-card featured" if featured else "post-card"
        return (f'<article class="{cls}" data-cats="{"|".join(c)}"><a class="post-img" href="https://theopragroup.com/{slug}" target="_blank" rel="noopener" tabindex="-1" aria-hidden="true">'
                f'<img src="{IMG}{img}" alt="" width="1200" height="900" loading="lazy"></a><div class="post-body"><div class="post-meta"><time datetime="{date}">{fmt(date)}</time>{tags}</div>'
                f'<h3><a href="https://theopragroup.com/{slug}" target="_blank" rel="noopener">{title}</a></h3><p>{ex}</p>'
                f'<a class="inline-link" href="https://theopragroup.com/{slug}" target="_blank" rel="noopener">Read article <span aria-hidden="true">→</span></a></div></article>')
    return f'''<main id="main">

<section class="page-hero">
  <div class="wrap">
    <p class="eyebrow eyebrow-light"><span class="dot"></span>Blog</p>
    <h1>Insight on hiring, HR <em>and careers.</em></h1>
    <p class="page-lead">Practical advice for employers and candidates from the OPRA team, from employment law changes to leading people well.</p>
  </div>
</section>

<section class="section blog">
  <div class="wrap">
    <div class="chips" role="group" aria-label="Filter articles by topic">{chips}</div>
    {card(POSTS[0], True)}
    <div class="post-grid">{"".join(card(p) for p in POSTS[1:])}</div>
    <p class="blog-more"><a class="button button-dark" href="https://theopragroup.com/opra-blog/page/2/" target="_blank" rel="noopener">See older articles</a></p>
  </div>
</section>

<section class="final-cta">
  <div class="wrap final-inner">
    <div><p class="eyebrow eyebrow-light">Need help, not just reading?</p><h2>Talk to <em>the team.</em></h2><p class="final-sub">Call <a href="{TEL}">{PHONE}</a></p></div>
    <div class="final-actions">
      <a class="button button-lime" href="#employer-dialog" data-open="employer-dialog" data-service="HR support">Request HR support</a>
      <a class="button button-outline-light" href="#cv-dialog" data-open="cv-dialog">Upload your CV</a>
    </div>
  </div>
</section>

</main>'''


# ---------------- About: values + team ----------------
VALUES = [
  ("01", "Customer focus", "Excellent service at every step.", "Clear communication from the first conversation to the first day."),
  ("02", "Integrity", "Relationships built on trust, honesty and respect.", "Straight answers on candidates, roles and timelines."),
  ("03", "Collaboration", "Working with you to reach your goals.", "We work alongside your team, not around it."),
  ("04", "Innovation", "Creative solutions to people challenges.", "Recruitment, screening and HR joined up, with fewer handovers."),
  ("05", "Inclusion", "Diversity and equality, with dignity and respect for everyone.", "Fair, consistent processes for every candidate."),
]


def about_values_team():
    vals = "".join(f'<article class="value-tile"><span class="value-num">{n}</span><h3>{t}</h3><p class="value-def">{p}</p></article>' for n, t, d, p in VALUES)
    team = "".join(person(r, a) for r, a in [
        ("Managing Director", "Leadership"), ("Dental Recruitment Consultant", "Dentistry"), ("Financial Services Consultant", "Finance"),
        ("Logistics Recruitment Consultant", "Logistics"), ("OPRA Flex Coordinator", "Temporary staffing"), ("HR Consultant", "HR &amp; people services"),
        ("Screening Specialist", "Screening &amp; re-vetting"), ("Candidate Support", "Candidates")])
    return f'''
<section class="section values-section" id="values">
  <div class="wrap">
    <div class="section-heading"><p class="eyebrow">What we stand for</p><h2>Our core <em>values.</em></h2><p class="section-intro">What you can expect from us, whether you are hiring or looking for work.</p></div>
    <div class="value-grid">{vals}</div>
  </div>
</section>

<section class="section team-section" id="team">
  <div class="wrap">
    <div class="section-heading"><p class="eyebrow">The people behind OPRA</p><h2>Meet <em>the team.</em></h2><p class="section-intro">Specialists across our industries and services. You'll always know who you're talking to.</p></div>
    <div class="team-grid">{team}</div>
    <p class="review-source">Placeholders: team photos, names and roles to be supplied by OPRA.</p>
  </div>
</section>
'''
