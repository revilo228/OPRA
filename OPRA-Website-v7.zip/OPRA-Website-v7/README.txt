OPRA GROUP: WEBSITE V7

How to view:
1. Unzip this folder.
2. Double click index.html. It opens in your browser.

What's new in v7:
- Menu button (3 lines) top left opens a side menu: About Us, Blog and the 3 industries.
  On phones and tablets it also holds Jobs & Careers, For Employers, the phone number and both CTAs.
- Industries drop-down in the top bar: Dentistry, Finance, Logistics.
- 3 industry pages (industry-dentistry.html, industry-finance.html, industry-logistics.html):
  experience, results with client logos, "Meet our [Industry] Team", and two sector CTAs
  (hire / find a role) that prefill the forms.
- blog.html: OPRA's 10 latest articles with topic filters.
- About Us: new core values section (5 cards) and a "Meet the team" grid.
- Service-specific CTAs on For Employers, e.g. "Request a screening quote", "Send a hiring brief".
  The employer form heading and button change to match the service picked.

Notes:
- Forms are preview only. Nothing is uploaded or sent.
- Keep HTML files, styles.css, script.js, config.js and assets together.
- Pages keep noindex/nofollow for review.
- _build/ holds the scripts used to generate v7. Not needed to view or deploy.
- See OPRA-Review-Notes.md for what OPRA must supply before launch.
