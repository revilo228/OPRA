/* Integration handoff. The forms are preview only and never send data.
   Connect a form service (e.g. Formspree) before launch.
   Contact details and social links are OPRA Group's own, from theopragroup.com. */
window.OPRA_CONFIG = {
  mode: "preview",
  phone: "+442045485066",
  jobsUrl: "https://jobs.theopragroup.com/",
  social: {
    linkedin: "https://www.linkedin.com/company/opragroup/",
    instagram: "https://www.instagram.com/opragroup/",
    tiktok: "https://www.tiktok.com/@opragroup",
    x: "https://x.com/opragroup"
  }
};
