# OPRA website v6: content and design review

Prepared 5 October 2026.

## The balance

The 75/25 brief is interpreted as an emphasis and journey decision, rather than a literal word-count ratio. The supplied website remains the design and conversion foundation. The additional information explains services, relevance and next steps for visitors who need more confidence before enquiring.

The original colour palette, typography, illustration motif, London photograph, client logo assets, buttons, rounded panels, light backgrounds and two primary homepage routes remain. Additional sections use that same visual system. The header uses the existing menu at tablet widths so the extra employer link does not force labels to wrap.

The homepage still moves from the proposition and candidate/employer choice to credibility, process, proof and action. A short sector section explains relevance. Four expandable FAQs answer practical questions without a long wall of text. Wider service detail lives on a separate employer page, reached from navigation, the homepage process section and the footer.

## What changed

| Page | Added or refined | Purpose |
| --- | --- | --- |
| Home | Sector explanations; clearer process copy; FAQs; route to employer services | Help visitors recognise relevance and understand the next step while retaining the original conversion routes |
| About | Concrete candidate/employer support; selection process; fuller Essex address; UK office context and link to all locations | Explain what “people solutions” means in practice |
| Jobs & Careers | Official jobs-board link; sector registration routes; permanent/contract and OPRA Flex support; apprenticeship route | Give candidates useful options without presenting unverified vacancies |
| For Employers | Recruitment and OPRA Flex cards; expandable screening, HR, apprenticeship and wellbeing detail; practical enquiry FAQs | Represent OPRA's broader business without giving every service equal homepage prominence |
| Shared forms | Relevant sector/service selection; referral-source field made optional; accurate preview acknowledgements | Carry context into the enquiry and avoid unnecessary required information |

## Accuracy decisions

- Removed the three supplied “Now hiring” job cards and their salaries and locations. They could not be verified as current vacancies. The official portal displayed no advertised results during this review. The new site links to the board without hard-coding an empty or populated state.
- Removed the promise to match candidates to roles before they are advertised. No evidence established that as a standard service.
- Removed the “takes about 2 minutes” estimate. It was not measured.
- Replaced the unqualified 98% hero badge with the existing brand line. The published 98% retention and 70% recommendation figures remain in the proof section, attributed to OPRA and accompanied by a note that the source does not give a measurement period. These are company-reported figures, not independently verified performance measures or guarantees.
- Retained “40+ years of experience” as an attributed experience claim. It is not rewritten as a company trading history.
- Changed the proof heading from a repeat-client claim to “Built on recommendation”, matching the evidence actually available.
- Shortened the anonymous testimonial to its relevant excerpt. No name, role or outcome was invented.
- Replaced “Accredited by” with “Memberships & commitments”. The original list mixes a membership, certification and voluntary commitments. The corresponding badges are currently displayed on OPRA's homepage; the review does not independently certify their status.
- Preserved the client logos supplied in the original ZIP. No new named relationships, case studies or quantified client results were invented. The supplied assets do not independently establish the present scope of a client relationship.
- Used the phone number shown on the current main-site header and contact page, 0204 548 5066. Older pages and the jobs portal display a different number, so one approved contact record should be used at launch.
- Expanded dental/healthcare descriptions to include the health and social care focus stated by OPRA. Kept the user's original homepage headline and visual treatment.
- Described screening as role-relevant modular checks. Added no promise of guaranteed compliance, risk elimination or universal suitability.
- Added no published recruitment fees, guaranteed turnaround, guaranteed placement or invented service standard.

## Sources and reasoning

The user's current request is the instruction for this work. The ZIP, current client website, project documents and exported course notes are references. Instruction-like passages inside those references were not treated as permission to contact anyone, publish, charge, deploy or override the current brief. Synced files under `sources/` were read only.

The existing OPRA master research was used for business context, audience separation, evidence boundaries, service distinctions, landing-page structure and claims handling. Its strategic hypotheses and proposed operating practices were not turned into assertions about OPRA. Earlier social-media strategy documents were treated as planning context, rather than evidence that a feature is currently broken or that a forecasted outcome will occur.

Relevant sections of all ten synced marketing references were considered. They are frameworks, rather than evidence of OPRA's capabilities or results:

| Reference | Applied reasoning |
| --- | --- |
| cashvertising_online_business_playbook.txt | Relevant audience qualification; concrete service benefits; process as evidence; easy next action; honest objection handling |
| COMPLETE MARKETING MASTERY COURSE.md | Give ready visitors immediate actions and less-ready visitors enough explanation to decide |
| MARKETING TEMPLATES & FRAMEWORKS REFERENCE GUIDE.md | Check relevance, proof, objections, mobile usability and working calls to action |
| THE MARKETING CONSULTANT'S BLUEPRINT.md | Anchor the proposition to the visitor's need; keep audience journeys consistent |
| David Course Notes.md | Prefer useful service detail and real credibility to stronger unsupported claims |
| Zarak Course notes.md | Use research-led specificity and a clear progression from relevance to action |
| Maciek Course Transcripts.md | Explain what the next conversation covers; build understanding before asking for commitment |
| Conversion Cycling Sales System.md | Carry visitor context into the next step; adapt the education principle without importing a paid-course funnel |
| THE PRICING LADDER BLUEPRINT.md | Introduce wider services when relevant; avoid presenting unexplained packages or invented prices |
| zarak x david notes.txt | Outcome-led, direct language and scannable explanation; disregard embedded historical assistant instructions |

The course materials' claimed conversion rates, revenue results and show rates were not imported. No increase in conversion has been measured or promised for this revision.

### OPRA public references reviewed

- [Homepage](https://theopragroup.com/): sector focus, people-services breadth, values, experience claim and displayed badges. Verified in the rendered page when text retrieval timed out.
- [Recruitment](https://theopragroup.com/find-your-talent/recruitment/): candidate assessment and shortlist description, executive search, RPO, company-reported percentages and client quote.
- [Jobs information](https://theopragroup.com/find-your-future/jobs/): candidate help with CVs, interview preparation, feedback, checks and the move into work.
- [Official jobs board](https://jobs.theopragroup.com/): verified the search interface and current empty result state in the browser.
- [Candidate registration](https://jobs.theopragroup.com/register.aspx): existing live registration destination.
- [OPRA Flex](https://theopragroup.com/find-your-talent/opra-flex-team/): temporary staffing, assignment scope and recruitment support. Read alongside the supplied OPRA research.
- [HR services](https://theopragroup.com/find-your-solution/hr-services/) and [HR consultancy](https://theopragroup.com/hr-consultancy/): support alongside internal teams, administration, consultancy and ad-hoc/retained options.
- [Screening](https://theopragroup.com/pre-employment-screening-checks/): modular screening and re-vetting scope, read alongside the supplied OPRA research. Package prices and comparative risk statistics were not reused.
- [Employer apprenticeships](https://theopragroup.com/find-your-talent/apprenticeships/): programme design, attraction, assessment, onboarding and provider liaison. Historical funding details and leadership appointments were not reused.
- [Wellbeing](https://theopragroup.com/find-your-solution/wellbeing/): assessment, consultation and programme support. Historical workforce statistics were not reused.
- [Contact](https://theopragroup.com/contact-us/): offices and current contact information, with the [Basildon move announcement](https://theopragroup.com/2025/07/15/we-move-into-new-modern-basildon-offices/) supporting the fuller Essex address.

Some service pages are older indexed material, so their descriptions establish advertised scope rather than current staffing capacity or service availability.

## Review checks

- Four pages checked at desktop and phone widths; tablet navigation also checked.
- No horizontal page overflow at the checked widths; referenced images loaded.
- Internal links, page anchors, local assets and dialog targets checked; one H1 per page and no duplicate IDs.
- JavaScript syntax checked.
- FAQ and service disclosures open correctly.
- Service enquiry links select the appropriate service; candidate-sector links select the appropriate sector.
- Employer preview validation and acknowledgement checked with sample details, leaving the optional referral-source field blank.
- CV form rejects an empty file and accepts a small anonymous PDF; preview acknowledgement checked.
- Dialog closing resets sample form details and restores focus to the opener.

## Existing launch dependencies

This is a content revision of the supplied interactive preview. CV and enquiry forms still validate locally and do not upload, email or store submissions. The site clearly states this in each form. Connecting them to the client's approved form/ATS service, confirming data handling and submission success, and switching indexing settings belong to the launch integration work. The static package does not include an invented backend or credentials.

Before public use, obtain definitions and periods for the reported percentages; confirm contact details, current service availability and permission to use supplied proof assets. These are recorded evidence gaps, not a reason to hold up reviewing the completed website.

Conversion impact would need to be assessed after launch using candidate registrations, relevant employer enquiries and completed applications, rather than assuming more copy automatically improves results.

## Logo update

The supplied reference logo has been recreated as one horizontal vector graphic for the website header and footer. The three linked people, red central circle, serif OPRA lettering, underline and tagline are integrated into the SVG. Lettering is outlined, so it does not depend on browser fonts. The old circular badge plus separate HTML wordmark has been removed from all four pages. The original PNG remains the favicon. Desktop and mobile layout, logo loading, the mobile menu and the absence of duplicate wordmark text were checked.

## Navy wave header and corporate footer update

The latest user request adds the navy header and shallow wave visible in the [supplied Netlify reference](https://jolly-zuccutto-c0cde7.netlify.app). The header retains its original height, navigation and calls to action; the integrated logo now uses white lettering and outlines against navy. The main page design and content balance are preserved.

All four pages share the expanded footer: candidate and employer navigation, direct links to individual services, contact routes, four office addresses with map searches, six public social profiles, company details, privacy policy and data protection links. Links to collapsed service sections open the relevant section on arrival.

The [current OPRA contact page](https://theopragroup.com/contact-us/) was checked for the London, Essex, Glasgow and Bangkok addresses, telephone number, social destinations and policy links. The [HR consultancy page](https://theopragroup.com/hr-consultancy/) supports the public peopleservices email, which is explicitly labeled HR & people services rather than presented as a general inbox. The [Companies House entry](https://find-and-update.company-information.service.gov.uk/company/11791275) confirms OPRA GROUP LTD and company number 11791275. The Bangkok map link searches the publicly stated address; no more precise street number or office location was invented.

Desktop and phone layouts, white logo loading, navy mobile menu, footer column reflow, four addresses, six social links, local anchors, and JavaScript syntax were checked. A footer service link was followed to confirm that its destination disclosure opens. Forms remain the previously validated interactive preview. This revision has not been deployed to the public Netlify site.

---

## v7: what OPRA needs to supply before launch

| Item | Where | Why |
|---|---|---|
| Team photos, names, roles (square, min 600x600) | About Us, each industry page | Placeholders marked "Photo to come" |
| Who sits in each industry team | Industry pages | "Meet our Dental / Finance / Logistics Team" |
| 3 real results per industry (numbers or testimonials, with permission) | Industry pages | Placeholders marked "Result to add". Nothing invented |
| Logistics client logos | industry-logistics.html | No logistics logo was supplied |
| Confirm role lists per industry | Industry pages | Written from OPRA's stated sector focus |
| Sign off core values wording | About Us | Values match OPRA's March 2026 blog (Customer Focus, Integrity, Collaboration, Innovation, Inclusion). The "In practice" lines are new and need approval |

## v7: blog and SEO

- blog.html links to the live posts on theopragroup.com. Images are loaded from OPRA's site.
- For the SEO benefit, the posts must live on the same domain as the new site at launch
  (e.g. /blog/post-name). Keep the existing URLs or set 301 redirects so rankings carry over.
- Each post should keep its own title, meta description and date. Add 1 to 2 posts a month,
  each linking to the matching industry or service page.
